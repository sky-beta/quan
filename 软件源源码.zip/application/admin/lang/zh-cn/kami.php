<?php

return [
    'Id'      => 'ID',
    'Kami'    => '卡密',
    'Udid'    => '设备码',
    'Jh'      => '是否激活',
    'Addtime' => '生成时间',
    'Usetime' => '使用时间',
    'Endtime' => '到期时间',
    'Kmyp'    => '卡密类型'
];
