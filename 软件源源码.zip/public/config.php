<?php
/*数据库配置*/
$dbconfig=array(
	"host" => "localhost", //数据库服务器
	"port" => 3306, //数据库端口
	"user" => "test123", //数据库用户名
	"dbname" => "test123", //数据库名
	"pwd" => "e4T7CPNE8Am7XCTE", //数据库密码
	"dbqz" => "shua" //数据表前缀
);
?>